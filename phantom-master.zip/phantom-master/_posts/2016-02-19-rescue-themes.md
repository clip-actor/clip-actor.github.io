---
layout: inner
position: right
title: 'Rescue Themes'
date: 2016-02-20 15:56:00
categories: development design
tags: WordPress PHP Sass
featured_image: '/img/posts/03_rescue-themes-1130x864-2x.png'
project_link: 'https://rescuethemes.com'
button_text: 'Visit Rescue Themes'
button_icon: 'wordpress'
lead_text: 'Designed and developed all WordPress themes'
---
